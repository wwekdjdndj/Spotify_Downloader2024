"""
Types for the spotdl package.
"""
